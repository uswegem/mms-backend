# MMS Master Module Flow
# Client Deliverable — End-to-End System Map

| Field | Value |
|-------|-------|
| **Document** | MMS Master Module Flow |
| **Version** | 1.0 Final |
| **Date** | 7 June 2026 |
| **Classification** | Client Deliverable |
| **Project** | Merchant Management System (MMS) — TANQR / TIPS Tanzania |

---

## Executive summary

The **Merchant Management System (MMS)** enables merchants and schools to accept **QR-based payments** and **digital school fee collections** across multiple Financial Service Providers (FSPs) — banks, mobile money operators, and third-party payment providers.

The platform is delivered in **five milestones**, from architecture and platform foundation through onboarding, payment processing, reconciliation, and executive reporting. All modules integrate with **TIPS** (national instant payment network) and **Core Banking System (CBS)** via the bank's **WSO2 API gateway**.

---

## Diagram legend

| Symbol | Meaning |
|--------|---------|
| **Solid arrow** | Primary business or data flow |
| **Dashed arrow** | External system integration (TIPS, CBS, FSP) |
| **Yellow band** | Project milestone (M1–M5) |
| **Cylinder** | Database / ledger store |
| **Maker-Checker** | Segregation of duties — two-person approval |

---

## Diagram 1 — Executive business flow (client view)

*High-level journey from onboarding to reporting.*

```mermaid
flowchart LR
  subgraph acquire [ACQUIRE]
    A1[Onboard Merchant / School]
    A2[KYC + Maker-Checker Approval]
    A3[CBS Account Validation]
  end

  subgraph register [REGISTER]
    B1[TIPS Merchant Registration]
    B2[Alias ID + TANQR Issuance]
  end

  subgraph transact [TRANSACT]
    C1[Payer scans QR / Lipa Namba]
    C2[FSP routes via TIPS]
    C3[MMS records payment]
  end

  subgraph settle [SETTLE & MATCH]
    D1[Settlement batch + approval]
    D2[CBS credit to merchant]
    D3[Reconcile MMS / TIPS / CBS]
  end

  subgraph insight [REPORT]
    E1[Dashboards & Analytics]
    E2[Notifications to merchant / parent]
  end

  A1 --> A2 --> A3 --> B1 --> B2
  B2 --> C1 --> C2 --> C3
  C3 --> D1 --> D2 --> D3
  D3 --> E1 --> E2
```

---

## Diagram 2 — Master module map (all milestones)

*Technical module view aligned to the 20-module architecture and five delivery milestones.*

```mermaid
flowchart TB
  subgraph actors [External Actors]
    direction LR
    BankOps[Bank Staff / Acquirer Operations]
    MerchantSchool[Merchant / School Administrator]
    PayerParent[Payer / Parent]
    FSPs[Issuer FSPs — Bank / MoMo / Third Party]
  end

  subgraph m1 [MILESTONE 1 — Architecture and System Planning]
    direction TB
    M1_Doc[Architecture + DB + Module Specs]
    M1_Auth[Authentication]
    M1_RBAC[Authorization / RBAC Foundation]
    M1_Users[User Management]
    M1_Audit[Audit Logs]
    M1_Config[Configuration Management]
    M1_DB[(PostgreSQL Database)]
    M1_Doc ~~~ M1_Auth
    M1_Users --> M1_Auth --> M1_RBAC
    M1_Config --> M1_RBAC
    M1_Audit -.-> M1_DB
  end

  subgraph m2 [MILESTONE 2 — Merchant Onboarding and QR Workflows]
    direction TB
    M2_Onboard[Merchant / School Onboarding + KYC]
    M2_Merchant[Merchant Management]
    M2_Status[Status: Active / Dormant / Suspended]
    M2_Alias[Alias Merchant ID — Lipa Namba]
    M2_QR[QR Management — Static and Dynamic TANQR]
    M2_Onboard --> M2_Merchant --> M2_Status
    M2_Merchant --> M2_Alias --> M2_QR
  end

  subgraph mc [Maker-Checker — Segregation of Duties]
    MC[Approval Workflow Engine]
  end

  subgraph m3 [MILESTONE 3 — TIPS/CBS Integration and Transactions]
    direction TB
    WSO2[WSO2 API Gateway]
    M3_TIPS[TIPS Integration]
    M3_CBS[CBS Integration]
    M3_Txn[Transaction Processing]
    M3_Webhook[Callback / Webhook Handler]
    M3_Ledger[(Transaction Ledger)]
    WSO2 --> M3_TIPS
    WSO2 --> M3_CBS
    M3_TIPS --> M3_Webhook --> M3_Txn --> M3_Ledger
    M3_CBS -.->|Account validation| M2_Onboard
  end

  subgraph m4 [MILESTONE 4 — School Fees and Reconciliation]
    direction TB
    M4_School[School Fee Collection]
    M4_Refs[Student / Invoice / Bill References]
    M4_Track[Fee Payment Tracking and Allocation]
    M4_Settle[Settlement Processing]
    M4_Recon[Reconciliation Engine]
    M4_Exc[Exception Handling and Matching]
    M4_School --> M4_Refs --> M4_Track
    M4_Track --> M3_Txn
    M3_Ledger --> M4_Settle
    M4_Settle --> M4_Recon --> M4_Exc
  end

  subgraph m5 [MILESTONE 5 — Reporting Dashboards and Admin Controls]
    direction TB
    M5_Portal[Admin Portal — Next.js]
    M5_Dash[Executive Dashboard]
    M5_Report[Merchant / School / Transaction / Settlement Reports]
    M5_Analytics[Operational Analytics]
    M5_Notify[Notifications — SMS / Email]
    M5_Monitor[System Monitoring]
    M5_Portal --> M5_Dash --> M5_Report --> M5_Analytics
  end

  subgraph external [National and Bank Infrastructure]
    direction LR
    TIPS[TIPS Switch and Directory]
    CBS[Core Banking System]
    S3[Document and QR Storage]
  end

  %% Portal access
  BankOps -->|Admin Portal| M5_Portal
  MerchantSchool -->|Merchant Portal| M5_Portal
  M5_Portal --> M1_Auth

  %% Onboarding operations
  BankOps --> M2_Onboard
  MerchantSchool --> M2_Merchant
  MerchantSchool --> M4_School

  %% Maker-checker gates
  M2_Onboard -->|Submit for approval| MC
  MC -->|Approve onboarding| M2_Merchant
  M4_Settle -->|Submit batch| MC
  MC -->|Approve settlement| M3_CBS

  %% TIPS registration and QR
  M2_Merchant --> M3_TIPS
  M3_TIPS <-->|Register merchant and alias| TIPS
  M2_QR --> S3
  M4_Refs -->|Dynamic QR per invoice| M2_QR

  %% Payment rail
  PayerParent -->|Scan QR or Lipa Namba| FSPs
  FSPs -->|Real-time payment| TIPS
  TIPS -->|Payment notification| M3_Webhook
  M3_Txn --> M5_Notify
  M3_Txn --> M5_Dash

  %% Settlement and CBS
  M3_CBS -->|Credit merchant account| CBS

  %% Three-way reconciliation
  TIPS -->|Settlement report| M4_Recon
  CBS -->|EOD account statement| M4_Recon
  M3_Ledger --> M4_Recon
  M4_Exc --> M5_Dash
  M4_Recon --> M5_Report

  %% Audit trail
  M1_Audit -.-> M2_Merchant
  M1_Audit -.-> M3_Txn
  M1_Audit -.-> M4_Recon

  %% Outputs
  M5_Report --> BankOps
  M5_Notify --> MerchantSchool
  M5_Notify --> PayerParent

  %% Build sequence
  m1 ~~~ m2 ~~~ m3 ~~~ m4 ~~~ m5
```

---

## End-to-end process (10 steps)

| Step | Phase | Description |
|------|-------|-------------|
| 1 | M1 | Bank or merchant user authenticates via Admin/Merchant Portal (JWT + RBAC) |
| 2 | M2 | Merchant or school application submitted with KYC documents |
| 3 | M2 | Maker-checker approves onboarding; merchant status set to **Active** |
| 4 | M2/M3 | CBS validates settlement account; TIPS registers merchant and Lipa Namba alias |
| 5 | M2 | Static or dynamic **TANQR** code issued per Bank of Tanzania standard |
| 6 | M3 | Payer initiates payment via any FSP; TIPS routes to acquirer |
| 7 | M3 | TIPS webhook received; transaction recorded in MMS ledger (idempotent) |
| 8 | M4 | School fee payments allocated to student invoices; settlement batch prepared |
| 9 | M4 | Maker-checker approves settlement; CBS credits merchant; daily recon runs |
| 10 | M5 | Exceptions resolved; dashboards and reports published; notifications sent |

---

## Milestone deliverable mapping (contract alignment)

### Milestone 1 — Architecture + Database/System Planning

| Deliverable | Module / artifact |
|-------------|-------------------|
| a) Final system architecture | `Enterprise-System-Architecture.md` |
| b) Database structure | `Database-Schema.md` + SQL migrations |
| c) Module breakdown | `Module-Breakdown.md` (20 modules) |
| d) User roles | RBAC matrix + 6 system roles |
| e) Workflow mapping | Sections 7–12 + this document |
| f) Technical implementation plan | Phased roadmap M1–M5 |

### Milestone 2 — Merchant Onboarding + QR Workflows

| Deliverable | Module |
|-------------|--------|
| a) Merchant/school onboarding workflows | 4 Merchant Onboarding |
| b) Merchant status management | 3 Merchant Management |
| c) Role-based access foundation | 1 Auth + 2 Authorization + 17 Users |
| d) Alias/merchant ID handling | 6 Alias Merchant ID |
| e) Static/dynamic QR generation workflow | 5 QR Management |

### Milestone 3 — TIPS/CBS Integrations + Transaction Processing

| Deliverable | Module |
|-------------|--------|
| a) TIPS/CBS integration structure | 18 TIPS + 19 CBS via WSO2 |
| b) Account validation flow | CBS → Onboarding |
| c) Transaction initiation/status handling | 8 Transactions |
| d) Callback/webhook processing | 8 Transactions (webhook controller) |
| e) Transaction ledger updates | Payment ledger + idempotency store |

### Milestone 4 — School Fee Module + Reconciliation System

| Deliverable | Module |
|-------------|--------|
| a) School fee collection workflow | 7 School Fee Collection |
| b) Student/invoice references | Fee catalog + invoicing |
| c) Fee payment tracking | Payment allocation engine |
| d) Reconciliation logic + exception handling | 10 Reconciliation |
| e) Matching TIPS/CBS/MMS records | Three-way reconciliation |

### Milestone 5 — Reporting Dashboards + Admin Controls

| Deliverable | Module |
|-------------|--------|
| a) Admin dashboards | 12 Dashboard |
| b) Merchant/school reports | 11 Reporting |
| c) Transaction reports | 11 Reporting |
| d) Settlement reports | 11 Reporting |
| e) Configuration controls | 16 Configuration |
| f) Operational analytics | 11 Reporting + 12 Dashboard |

---

## Cross-cutting controls

| Control | Module | Applies to |
|---------|--------|------------|
| Maker-checker | 14 | Merchant onboarding approval, settlement batch approval |
| Audit trail | 15 | All status changes, payments, approvals |
| Notifications | 13 | Payment confirmations, settlement advice, KYC decisions |
| System monitoring | 20 | Health, uptime, API latency |

---

## Compliance and standards

| Requirement | How MMS addresses it |
|-------------|---------------------|
| TANQR Code Standard (BoT) | QR module — CRC16, Annex 2 layout, ID 26 domain |
| TIPS integration | Registration, webhooks, settlement files, Lipa Namba |
| Maker-checker (bank policy) | Module 14 gates onboarding and settlement |
| 60 TPS / 50 concurrent users | Horizontal scaling, Redis, connection pooling |
| ≤ 8 second response time | API caching, async workers for heavy operations |
| SSL + encryption | TLS 1.3, encryption at rest, JWT rotation |

---

## Related deliverable documents

| Document | Path |
|----------|------|
| Enterprise System Architecture | `Architecture/Enterprise-System-Architecture.md` |
| Module Breakdown | `Architecture/Module-Breakdown.md` |
| Database Schema | `Database/docs/Database-Schema.md` |
| API Specification | `Docs/REST-API-Specification.md` |
| Business Requirements | `Docs/BRD-Merchant-Management-System.md` |
| Flow diagram PNG (executive) | `Docs/diagrams/png/MMS-Executive-Business-Flow.png` |
| Flow diagram PNG (module map) | `Docs/diagrams/png/MMS-Master-Module-Flow.png` |

---

**Prepared for client sign-off.**

*Bank of Tanzania TANQR / TIPS aligned · Acquirer Merchant Management Platform*
